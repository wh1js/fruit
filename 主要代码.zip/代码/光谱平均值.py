import json

# 定义字段顺序
keys_order = ['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8',
              'Clear1', 'NIR1', 'Clear2', 'NIR2']

# 存储所有行的数据
rows = []

# 读取specturm.txt并解析数据
with open('specturm.txt', 'r') as f:
    for line in f:
        data = json.loads(line)
        # 提取内部字典（如{"F1": 4103, ...}）
        inner_dict = list(data.values())[0]
        # 按顺序提取数值
        row = [inner_dict[key] for key in keys_order]
        rows.append(row)

# 计算每列的平均值
averages = [sum(col) / 4 for col in zip(*rows)]

# 格式化为两位小数并写入文件
output_line = ' '.join(f"{avg:.2f}" for avg in averages)
with open('avg.txt', 'w') as f:
    f.write(output_line)