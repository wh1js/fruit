import os
from ultralytics import YOLO
import cv2
import math
len1=[]

blackp_count=0
# 加载 YOLOv11 模型
model = YOLO('best3.pt')  # 替换为你的模型路径

fruits_s=[]
for i in range(0,4):
# 加载图像
    image_path = 'image_{}.jpg'.format(2)  # 替换为你的图像路径
    image = cv2.imread(image_path)

    # 进行目标检测
    results = model.predict(image_path,save=True)

    # 初始化 blackpoint 计数器
    blackpoint_count = 0
    # 初始化 loquat 角点列表
    loquat_corners_list = []

    # 提取检测结果
    for result in results:
        boxes = result.boxes.xyxy  # 获取边界框坐标 [x_min, y_min, x_max, y_max]
        scores = result.boxes.conf  # 获取置信度
        classes = result.boxes.cls  # 获取类别索引
        class_names = [model.names[int(cls)] for cls in classes]  # 获取类别名称

        # 遍历每个检测框
        for box, score, class_name in zip(boxes, scores, class_names):
            x_min, y_min, x_max, y_max = [int(item) for item in box.tolist()]  # 转换为列表
            if class_name == 'loquat':
                # 计算 loquat 的四个角点坐标
                corners = [
                    (x_min, y_min),  # 左上角
                    (x_max, y_min),  # 右上角
                    (x_max, y_max),  # 右下角
                    (x_min, y_max)   # 左下角
                ]
                lenguo=x_max-x_min
                #print(corners)


            elif class_name == 'blackpoint':
                # 统计 blackpoint 数量
                blackpoint_count += 1
                #print(x_min, y_min, x_max, y_max)
                #black_area_img = image[y_min:y_max,x_min:x_max, ...]
                center_x, center_y= (x_min+x_max)//2, (y_min+y_max)//2
                w= (x_max-x_min) // 2 -10
                h= (y_max-y_min) // 2 -5
                cv2.ellipse(image,(center_x,center_y),(h,w),0,0,360,(82,139,139),-1)
                s=math.pi * h * w
                fruits_s.append(s)
                #print("面积:{}".format(s))

                # 输出结果


    #print(f"\n黑点数: {blackpoint_count}")

    blackp_count+=blackpoint_count

    #像素
    #print(f"\nFurit len: {lenguo}")

    # 显示图像（保留原可视化逻辑）
    cv2.imwrite('result{}.jpg'.format(i),image)
    cv2.imshow('blackpoint',image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


    #缩放比
    n=0.012218045112781954
    #print("\n果径:{}".format(n*lenguo))
    len1.append(n*lenguo)


print("最终果径:{}".format(max(len1)))
print("面积:{}".format((sum(fruits_s)/len(fruits_s))*n*n))
print("黑点数:{}".format(blackp_count))






#获取文件名
# 定义 runs/detect 目录路径
detect_dir = './runs/detect'

# 获取所有以 'predict' 开头的文件夹
predict_folders = [f for f in os.listdir(detect_dir) if os.path.isdir(os.path.join(detect_dir, f)) and f.startswith('predict')]

# 提取文件夹名的数字后缀并找到最大值
max_number = -1
max_folder = None
for folder in predict_folders:
    try:
        # 提取 predict 后的数字（假设格式为 predictX，X 是数字）
        number = int(folder.replace('predict', ''))
        if number > max_number:
            max_number = number
            max_folder = folder
    except ValueError:
        continue  # 忽略无法转换为数字的文件夹

# 如果找到有效文件夹，列出其中的文件名
if max_folder:
    folder_path = os.path.join(detect_dir, max_folder)
    files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
    #print(f"最大编号的 predict 文件夹: {max_folder}")
    #print("文件夹中的文件名:")
    #for file in files:
        #print(file)


for i in range(0,4):
    img1 = cv2.imread('./runs/detect/{}/{}'.format(max_folder,files[i]))
    img2 = cv2.imread('result{}.jpg'.format(i))

# 横向拼接图像
    result = cv2.hconcat([img1, img2])

# 显示拼接后的图像
    cv2.imwrite('rt{}.jpg'.format(i),result)
    cv2.imshow('Horizontal Concatenation', result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()










import cv2
import numpy as np


def concatenate_images_vertically(images):
    """
    Concatenate a list of images vertically.

    Args:
        images (list): List of images as NumPy arrays.

    Returns:
        np.ndarray: Vertically concatenated image.
    """
    if not images:
        raise ValueError("No images provided for concatenation.")

    # Check if all images have the same width
    widths = [img.shape[1] for img in images]
    if len(set(widths)) > 1:
        # Resize all images to the minimum width
        min_width = min(widths)
        images = [cv2.resize(img, (min_width, img.shape[0])) for img in images]

    # Concatenate images vertically
    concatenated_image = np.vstack(images)
    return concatenated_image


# Example usage
def main():
    # Load images (replace with your image paths)
    tr0 = cv2.imread('rt0.jpg')
    tr1 = cv2.imread('rt1.jpg')
    tr2 = cv2.imread('rt2.jpg')
    tr3 = cv2.imread('rt3.jpg')

    # Check if all images are loaded successfully
    images = [tr0, tr1, tr2, tr3]
    if any(img is None for img in images):
        raise FileNotFoundError("One or more images failed to load. Check file paths.")

    # Concatenate images
    result = concatenate_images_vertically(images)

    # Save or display the result
    cv2.imwrite('concatenated_image.jpg', result)
    cv2.imshow('Concatenated Image', result)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()