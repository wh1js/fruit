with open('measure.txt', 'r') as file:
    content = file.read().strip()
    numbers = []
    for num_str in content.split():
        if '.' in num_str:
            numbers.append(float(num_str))
        else:
            numbers.append(int(num_str))
print(numbers)