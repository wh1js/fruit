import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, random_split
import json

# --- Dataset Processing ---
def read_data_from_folder(folder_path):
    measure_file = os.path.join(folder_path, 'measure.txt')
    label_file = os.path.join(folder_path, 'label.txt')
    with open(measure_file, 'r') as f:
        measure_data = np.array([list(map(float, line.strip().split())) for line in f])
    with open(label_file, 'r') as f:
        label_data = np.array([list(map(float, line.strip().split())) for line in f])
    return measure_data, label_data

# Load and combine data
data_dir = 'data1'
all_measure_data = []
all_label_data = []
for subfolder in os.listdir(data_dir):
    subfolder_path = os.path.join(data_dir, subfolder)
    if os.path.isdir(subfolder_path):
        measure, label = read_data_from_folder(subfolder_path)
        all_measure_data.append(measure)
        all_label_data.append(label)
all_measure_data = np.vstack(all_measure_data)  # Shape: (num_samples, 12)
all_label_data = np.vstack(all_label_data)      # Shape: (num_samples, 3)

# 归一化处理
measure_mean = np.mean(all_measure_data, axis=0)
measure_std = np.std(all_measure_data, axis=0)
label_mean = np.mean(all_label_data, axis=0)
label_std = np.std(all_label_data, axis=0)
normalized_measure = (all_measure_data - measure_mean) / measure_std
normalized_label = (all_label_data - label_mean) / label_std

# 保存归一化参数
np.save('measure_mean.npy', measure_mean)
np.save('measure_std.npy', measure_std)
np.save('label_mean.npy', label_mean)
np.save('label_std.npy', label_std)

# 定义Dataset
class RegressionDataset(Dataset):
    def __init__(self, measure, label):
        self.measure = torch.tensor(measure, dtype=torch.float32)
        self.label = torch.tensor(label, dtype=torch.float32)

    def __len__(self):
        return len(self.measure)

    def __getitem__(self, idx):
        return self.measure[idx], self.label[idx]

# 数据集划分
dataset = RegressionDataset(normalized_measure, normalized_label)
train_size = int(0.8 * len(dataset))
val_size = len(dataset) - train_size
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])
batch_size = 32
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)

# --- 模型定义 ---
class CNNLSTMModel(nn.Module):
    def __init__(self):
        super(CNNLSTMModel, self).__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=128, kernel_size=12, stride=1),  # 修改kernel_size为12
            nn.ReLU()
        )
        self.lstm = nn.LSTM(input_size=128, hidden_size=256, num_layers=1, batch_first=True)
        self.fc = nn.Linear(256, 3)

    def forward(self, x):
        x = x.unsqueeze(1)    # [batch_size, 1, 12]
        x = self.cnn(x)       # [batch_size, 128, 1]
        x = x.squeeze(2)      # [batch_size, 128]
        x = x.unsqueeze(1)    # [batch_size, 1, 128]
        out, _ = self.lstm(x) # [batch_size, 1, 256]
        out = out[:, -1, :]   # [batch_size, 256]
        out = self.fc(out)    # [batch_size, 3]
        return out

# --- 训练配置 ---
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = CNNLSTMModel().to(device)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 训练和验证函数（保持不变）
def train(model, train_loader, criterion, optimizer, device):
    model.train()
    running_loss = 0.0
    for inputs, labels in train_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * inputs.size(0)
    return running_loss / len(train_loader.dataset)

def validate(model, val_loader, criterion, device):
    model.eval()
    running_loss = 0.0
    with torch.no_grad():
        for inputs, labels in val_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            running_loss += loss.item() * inputs.size(0)
    return running_loss / len(val_loader.dataset)

# 训练循环
num_epochs = 50
for epoch in range(num_epochs):
    train_loss = train(model, train_loader, criterion, optimizer, device)
    val_loss = validate(model, val_loader, criterion, device)
    print(f'Epoch {epoch + 1}/{num_epochs}, Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}')

torch.save(model.state_dict(), 'model.pth')
# --- 推理示例 ---
def normalize_input(input_data, mean, std):
    return (input_data - mean) / std

def denormalize_output(output_data, mean, std):
    return output_data * std + mean

# 加载参数
measure_mean = np.load('measure_mean.npy')
measure_std = np.load('measure_std.npy')
label_mean = np.load('label_mean.npy')
label_std = np.load('label_std.npy')

# 加载模型
model.load_state_dict(torch.load('model.pth'))
model.to(device)
model.eval()


#提取光谱文件
keys_order = ['F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8',
              'Clear1', 'NIR1', 'Clear2', 'NIR2']

# 存储所有行的数据
rows = []

# 读取specturm.txt并解析数据
with open('specturm.txt', 'r') as f:
    for line in f:
        data = json.loads(line)
        # 提取内部字典（如{"F1": 4103, ...}）
        inner_dict = list(data.values())[0]
        # 按顺序提取数值
        row = [inner_dict[key] for key in keys_order]
        rows.append(row)

# 计算每列的平均值
averages = [sum(col) / 4 for col in zip(*rows)]
# 格式化为两位小数并写入文件
output_line = ' '.join(f"{avg:.2f}" for avg in averages)
with open('avg.txt', 'w') as f:
    f.write(output_line)

#提取光谱平均值txt文件
with open('avg.txt', 'r') as file:
    content = file.read().strip()
    numbers = []
    for num_str in content.split():
        if '.' in num_str:
            numbers.append(float(num_str))
        else:
            numbers.append(int(num_str))



# 输入应为12个特征
new_input = np.array(numbers)  # 示例输入
normalized_input = normalize_input(new_input, measure_mean, measure_std)
input_tensor = torch.tensor(normalized_input, dtype=torch.float32).unsqueeze(0).to(device)  # Shape: [1, 12]

with torch.no_grad():
    prediction = model(input_tensor)
    prediction = prediction.cpu().numpy()[0]
    real_prediction = denormalize_output(prediction, label_mean, label_std)
    print("Predicted real values:", real_prediction)