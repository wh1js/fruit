from docxtpl import DocxTemplate, RichText, InlineImage
from docx.shared import Cm

from snapshot_selenium import snapshot as driver
from pyecharts import options as opts
from pyecharts.charts import Bar, Line, Scatter
from pyecharts.render import make_snapshot
import json

with open("specturm.txt", "r", encoding="utf-8") as f:
    spectrum = [json.loads(data) for data in f.read().splitlines()]

x_data = list(spectrum[0]["0"].keys())
y_data = {list(line.keys())[0]: [line[list(line.keys())[0]][wave_band] for wave_band in x_data] for line in spectrum}

def bar_chart(x_axis, y_axis) -> Bar:
    c = Line()
    c.add_xaxis(x_axis)
    for name, data in y_axis.items():
        c.add_yaxis(f"{name}", data)
    c.set_series_opts(label_opts=opts.LabelOpts(position="right"))
    c.set_global_opts(title_opts=opts.TitleOpts(title="光谱分布图"))

    return c


spectrum_image_name = "line.png"
# 需要安装 snapshot-selenium 或者 snapshot-phantomjs
make_snapshot(driver, bar_chart(x_data, y_data).render(), spectrum_image_name)


template_doc = DocxTemplate('dangerous_area1.docx')

info_dict = {
    "dangerous_image": InlineImage(template_doc, spectrum_image_name, width=Cm(14)),
    "f_pinzhi": "优良",
    "visit_records": [
        {
            "ph": 0,
            "water": 0,
            "sugar": 0,
            "black": 0,
            "guojin": 0,
            "area": 0
        }
    ]
}

template_doc.render(info_dict)
template_doc.save('test.docx')
